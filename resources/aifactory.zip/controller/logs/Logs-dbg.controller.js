sap.ui.define([
    "ai/factory/controller/BaseController",
    "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
    "use strict";

    return BaseController.extend("ai.factory.controller.logs.Logs", {
        onInit: function () {
            // Initialize Logs model
            var oModel = new JSONModel({
                logs: [],
                filters: {
                    level: "all",
                    service: "all",
                    agent: "all"
                },
                isLoading: false
            });
            this.getView().setModel(oModel, "logs");
        },

        onNavBack: function () {
            this.navTo("home");
        }
    });
});